module.exports = {
  findById: jest.fn(),
  find: jest.fn()
};