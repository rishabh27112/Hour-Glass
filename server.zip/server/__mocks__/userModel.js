module.exports = {
  findById: jest.fn()
};