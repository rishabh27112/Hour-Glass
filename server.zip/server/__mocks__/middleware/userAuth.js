module.exports = (req, res, next) => {
  req.userId = 'test-user-id';
  next();
};
