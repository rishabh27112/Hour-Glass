

import express from 'express';
import userAuth from '../middleware/userAuth.js';
import TimeEntry from '../models/TimeEntry.js';
import userModel from '../models/userModel.js';
import Project from '../models/ProjectModel.js'; // <-- IMPORT PROJECT MODEL
import { classifyActivity } from '../services/classificationService.js'; // <-- IMPORT OUR NEW SERVICE
import { generateDailySummary, generateManagerSummary } from '../services/aiService.js';
import AiSummary from '../models/AiSummaryModel.js';

const router = express.Router();

// POST /api/time-entries - Store a complete appointment/time entry
router.post('/', userAuth, async (req, res) => {
  try {
    const { appointment, projectId, description } = req.body;
    if (!appointment || !appointment.apptitle || !appointment.appname || !appointment.startTime || appointment.duration == null) {
      return res.status(400).json({ msg: 'Invalid appointment payload. Required: apptitle, appname, startTime, duration' });
    }

    // 1. Resolve username
    const currentUser = await userModel.findById(req.userId).select('username');
    if (!currentUser) return res.status(401).json({ msg: 'User not found' });
    const username = currentUser.username;

    // 2. Classify the activity (using Rules DB + AI)
    const suggestedCategory = await classifyActivity(appointment);
    
    let finalIsBillable = false;
    
    // 3. Check the Project's billable status
    if (projectId) {
      const project = await Project.findById(projectId).select('isBillable');
      if (project && project.isBillable && suggestedCategory === 'billable') {
        finalIsBillable = true;
      }
    }

    // 4. Find or create the TimeEntry document for this user+project
    let timeEntry = await TimeEntry.findOne({ userId: username, project: projectId });
    
    if (!timeEntry) {
      // Create new document
      timeEntry = new TimeEntry({
        userId: username,
        project: projectId,
        appointments: []
      });
    }

    // 5. Find or create the appointment group for this taskId
    const taskId = description || 'default'; // Use description as taskId
    let appointmentGroup = timeEntry.appointments.find(a => a.taskId === taskId && a.appname === appointment.appname && a.apptitle === appointment.apptitle);
    
    if (!appointmentGroup) {
      // Create new appointment group
      appointmentGroup = {
        apptitle: appointment.apptitle,
        appname: appointment.appname,
        taskId: taskId,
        suggestedCategory: suggestedCategory,
        isBillable: finalIsBillable,
        timeIntervals: []
      };
      timeEntry.appointments.push(appointmentGroup);
    }

    // 6. Add the time interval
    appointmentGroup.timeIntervals.push({
      startTime: new Date(appointment.startTime),
      endTime: appointment.endTime ? new Date(appointment.endTime) : new Date(),
      duration: Number(appointment.duration)
    });

    const savedEntry = await timeEntry.save();
    const populatedEntry = await savedEntry.populate('project', 'ProjectName Description status');
    res.status(201).json(populatedEntry);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
});

// (start/stop endpoints removed) Clients should send a complete appointment
// object to POST /api/time-entries and the server will store it as-is.


// GET /api/time-entries - Get all time entries for a user
router.get('/', userAuth, async (req, res) => {
 try {
  const currentUser = await userModel.findById(req.userId).select('username');
  if (!currentUser) return res.status(401).json({ msg: 'User not found' });
  const username = currentUser.username;

  // optional query filters: projectId, task (task id or task title substring)
  const { projectId, task } = req.query;

  const query = { userId: username };
  if (projectId) query.project = projectId;

  // base query - get all time entries for this user
  let entries = await TimeEntry.find(query)
    .populate('project', 'ProjectName Description status')
    .sort({ createdAt: -1 })
    .exec();

  // Filter by task if provided (matches taskId or apptitle in any appointment)
  if (task) {
    const safe = String(task).trim();
    const regex = new RegExp(safe.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&'), 'i');
    entries = entries.filter(e => 
      e.appointments && e.appointments.some(apt => 
        (apt.taskId && regex.test(apt.taskId)) || 
        (apt.apptitle && regex.test(apt.apptitle))
      )
    );
  }

  res.json(entries);
 } catch (err) {
   console.error(err);
   res.status(500).send('Server Error');
 }
});


// DELETE /api/time-entries/:id - Delete a time entry
router.delete('/:id', userAuth, async (req, res) => {
 try {
   const currentUser = await userModel.findById(req.userId).select('username');
   if (!currentUser) return res.status(401).json({ msg: 'User not found' });
   const username = currentUser.username;
   const entry = await TimeEntry.findOne({ _id: req.params.id, userId: username });
   if (!entry) {
     return res.status(404).json({ msg: 'Time entry not found' });
   }
   await entry.deleteOne();
   res.json({ msg: 'Time entry removed' });
 } catch (err) {
  console.error(err);
  res.status(500).send('Server Error');
 }
});


// POST /api/time-entries/daily-summary/manager - manager-only summary for a project team
// body: { projectId: string, date?: ISODateString }
router.post('/daily-summary/manager', userAuth, async (req, res) => {
  try {
    const { projectId, date } = req.body || {};
    if (!projectId) return res.status(400).json({ msg: 'projectId is required' });

    // Ensure authentication middleware set req.userId (mirror project creation auth checks)
    if (!req.userId) {
      console.error('Missing req.userId in manager daily-summary - userAuth may have failed');
      return res.status(401).json({ msg: 'Authentication required' });
    }

    // resolve current user and check manager rights
    const currentUser = await userModel.findById(req.userId).select('username name');
    if (!currentUser) return res.status(401).json({ msg: 'User not found' });

    const project = await Project.findById(projectId).populate('members', 'username name').populate('createdBy', 'username name');
    if (!project) return res.status(404).json({ msg: 'Project not found' });

    const creatorId = project.createdBy && (project.createdBy._id || project.createdBy);
    if (!creatorId || creatorId.toString() !== req.userId) {
      return res.status(403).json({ msg: 'Only the project owner/manager can request team summaries' });
    }

    const target = date ? new Date(date) : new Date();
    const dayStart = new Date(target); dayStart.setHours(0,0,0,0);
    const dayEnd = new Date(target); dayEnd.setHours(23,59,59,999);

    const members = (project.members || []).slice();
    if (members.length === 0) return res.status(200).json({ ok: true, summary: `No members on project ${project.ProjectName || project._id}` });

    const reports = [];
    for (const m of members) {
      const memberUsername = m.username || (typeof m === 'string' ? m : null);
      if (!memberUsername) continue;

      const entries = await TimeEntry.find({
        userId: memberUsername,
        'appointment.startTime': { $gte: dayStart, $lte: dayEnd }
      }).populate('project', 'ProjectName').sort({ 'appointment.startTime': -1 }).exec();

      const items = entries.map(e => ({
        apptitle: e.appointment && e.appointment.apptitle,
        appname: e.appointment && e.appointment.appname,
        start: e.appointment && e.appointment.startTime,
        end: e.appointment && e.appointment.endTime,
        duration: e.appointment && e.appointment.duration,
        project: e.project ? (e.project.ProjectName || String(e.project)) : null,
      }));

      const summary = await generateDailySummary({ items, username: memberUsername, date: dayStart.toISOString() });
      reports.push({ username: memberUsername, items, itemsCount: items.length, summary });
    }

    const managerName = currentUser.username || currentUser.name || 'manager';
    const managerSummary = await generateManagerSummary({ reports, managerName, date: dayStart.toISOString() });

    // Persist the manager summary (upsert for project+date)
    try {
      await AiSummary.findOneAndUpdate(
        { type: 'manager', project: projectId, date: dayStart },
        {
          $set: {
            manager: currentUser._id || req.userId,
            managerUsername: managerName,
            summary: managerSummary,
            reports: reports
          }
        },
        { upsert: true, new: true, setDefaultsOnInsert: true }
      );
    } catch (persistErr) {
      console.error('Failed to persist manager summary', persistErr);
      // Do not fail the request if save fails; just continue returning the summary
    }

    return res.json({ ok: true, managerSummary, reportsCount: reports.length });
  } catch (err) {
    console.error('manager daily-summary error', err);
    return res.status(500).json({ ok: false, error: String(err && (err.message || err)) });
  }
});




// GET /api/time-entries/ai-summary/manager/:projectId?date=YYYY-MM-DD
router.get('/ai-summary/manager/:projectId', userAuth, async (req, res) => {
  try {
    const { projectId } = req.params;
    const { date } = req.query;
    if (!projectId) return res.status(400).json({ msg: 'projectId is required' });
    let dayStart = date ? new Date(date) : new Date();
    dayStart.setHours(0,0,0,0);
    const summary = await AiSummary.findOne({
      type: 'manager',
      project: projectId,
      date: dayStart
    });
    if (!summary) return res.status(404).json({ msg: 'No summary found for this project/date' });
    res.json({ ok: true, summary });
  } catch (err) {
    console.error('GET ai-summary error', err);
    res.status(500).json({ ok: false, error: String(err && (err.message || err)) });
  }
});

export default router;